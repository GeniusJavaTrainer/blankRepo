package com.employee.serviceimpl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.employee.entity.Employee;
import com.employee.entity.User;
import com.employee.exception.EmployeeNotFoundException;
import com.employee.model.EmployeeDTO;
import com.employee.repository.EmployeeRepository;
import com.employee.service.EmployeeService;
import com.employee.util.Converter;

@Service
public class EmployeeServiceImpl implements EmployeeService {

	@Autowired
	private EmployeeRepository employeeRepo;

	@Autowired
	private Converter converter;

//	@Autowired
//	private UserRepository userRepo;

	@Override
	public String registerEmployee(EmployeeDTO employeeDTO) {
		String message = null;
		Employee employee = null;
		
		employee = employeeRepo.save(converter.convertToEmployeeEntity(employeeDTO));
		
		if (employee != null) {
			message = "Registration successful.";
		}
		return message;
	}

	@Override
	public String updateEmployee(EmployeeDTO employeeDTO) throws EmployeeNotFoundException {
		Optional<Employee> employee = employeeRepo.findById(employeeDTO.getUserId());

		Employee emplr = new Employee();

		String message = null;
		
		if (employee.isPresent()) {
			emplr = converter.convertToEmployeeEntity(employeeDTO);
			emplr = employeeRepo.save(emplr);
			
			if(emplr != null) {
				message = new String("Record updated successfully.");
			}
		} else {
			throw new EmployeeNotFoundException("No such Employer");
		}
		
		return message;
	}

	@Override
	public User loginEmployee(String userName, String password) throws EmployeeNotFoundException {
		/*
		 * User user = userRepo.findByUserNameAndPassword(userName, password); UserDTO
		 * userDTO = new UserDTO();
		 * 
		 * if(user != null) { userDTO = converter. }
		 */
		
		return null;
	}

	@Override
	public String deleteEmployee(int employeeId) throws EmployeeNotFoundException {
		Optional<Employee> employee = employeeRepo.findById(employeeId);

		String message = null;
		
		if (employee.isPresent()) {
			employeeRepo.deleteById(employeeId);
			
			message = new String("Record deleted successfully.");
		}else {
			throw new EmployeeNotFoundException("No such Employee");
		}
		
		return message;
	}

	@Override
	public EmployeeDTO getEmployee(int employeeId) throws EmployeeNotFoundException {
		Optional<Employee> employee = employeeRepo.findById(employeeId);

		Employee empl = null;
		
		if (employee.isPresent()) {
			empl = employee.get();
		}else {
			throw new EmployeeNotFoundException("No such Employee");
		}
		
		return converter.convertToEmployeeDTO(empl);
	}

	@Override
	public List<EmployeeDTO> getEmployees() {
		List<Employee>employees = employeeRepo.findAll();
		
		List<EmployeeDTO>employeeDTOs = new ArrayList<>();
		
		for(Employee employee : employees) {
			employeeDTOs.add(converter.convertToEmployeeDTO(employee));
		}
		return employeeDTOs;
	}
}